var struct_ufe_1_1_cell_info =
[
    [ "CellInfo", "struct_ufe_1_1_cell_info.html#a270541a1b2c746a8b76b033f6f1de231", null ],
    [ "CellInfo", "struct_ufe_1_1_cell_info.html#ae9f22e40a90420f055435533053ede72", null ],
    [ "CellInfo", "struct_ufe_1_1_cell_info.html#a8a0965c49ca45bad9b542f3fa4b1358b", null ],
    [ "fontBold", "struct_ufe_1_1_cell_info.html#adf036a27d49b67fe0131ea0d7d0bc3cf", null ],
    [ "fontItalics", "struct_ufe_1_1_cell_info.html#aece496915f5da0277cc7b03651f577f6", null ],
    [ "fontName", "struct_ufe_1_1_cell_info.html#a7a0f11ef551f384d0b5f7f53423f702b", null ],
    [ "fontPointSize", "struct_ufe_1_1_cell_info.html#a2fc1656abddc8dcaa4ff00cb2d1d8d08", null ],
    [ "fontStrikeout", "struct_ufe_1_1_cell_info.html#a38f22372176c95a833adec01bd554071", null ],
    [ "textBgColor", "struct_ufe_1_1_cell_info.html#a424f1776aab8fe54c684d401d89da8c7", null ],
    [ "textFgColor", "struct_ufe_1_1_cell_info.html#a3aaf376c5e10e7d9bf2fdaa523d6f346", null ]
];