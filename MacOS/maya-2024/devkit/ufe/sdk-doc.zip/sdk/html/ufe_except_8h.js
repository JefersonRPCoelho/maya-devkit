var ufe_except_8h =
[
    [ "Ufe::InvalidRunTimeName", "class_ufe_1_1_invalid_run_time_name.html", "class_ufe_1_1_invalid_run_time_name" ],
    [ "Ufe::InvalidRunTimeId", "class_ufe_1_1_invalid_run_time_id.html", "class_ufe_1_1_invalid_run_time_id" ],
    [ "Ufe::InvalidOperationOnPath", "class_ufe_1_1_invalid_operation_on_path.html", "class_ufe_1_1_invalid_operation_on_path" ],
    [ "Ufe::InvalidOperationOnPathSegment", "class_ufe_1_1_invalid_operation_on_path_segment.html", "class_ufe_1_1_invalid_operation_on_path_segment" ],
    [ "Ufe::InvalidValueGet", "class_ufe_1_1_invalid_value_get.html", "class_ufe_1_1_invalid_value_get" ]
];