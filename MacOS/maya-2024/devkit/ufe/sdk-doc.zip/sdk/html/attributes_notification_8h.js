var attributes_notification_8h =
[
    [ "Ufe::AttributeChanged", "class_ufe_1_1_attribute_changed.html", "class_ufe_1_1_attribute_changed" ],
    [ "Ufe::AttributeValueChanged", "class_ufe_1_1_attribute_value_changed.html", "class_ufe_1_1_attribute_value_changed" ],
    [ "Ufe::AttributeAdded", "class_ufe_1_1_attribute_added.html", "class_ufe_1_1_attribute_added" ],
    [ "Ufe::AttributeRemoved", "class_ufe_1_1_attribute_removed.html", "class_ufe_1_1_attribute_removed" ],
    [ "Ufe::AttributeConnectionChanged", "class_ufe_1_1_attribute_connection_changed.html", "class_ufe_1_1_attribute_connection_changed" ],
    [ "Ufe::AttributeMetadataChanged", "class_ufe_1_1_attribute_metadata_changed.html", "class_ufe_1_1_attribute_metadata_changed" ]
];