var class_ufe_1_1_undoable_command_mgr =
[
    [ "Ptr", "class_ufe_1_1_undoable_command_mgr.html#ad93b8b3b0c1ac00b98b83af410e25155", null ],
    [ "UndoableCommandMgr", "class_ufe_1_1_undoable_command_mgr.html#a3a1c14aebde6b95ecd5116c31eb7b1ea", null ],
    [ "~UndoableCommandMgr", "class_ufe_1_1_undoable_command_mgr.html#a981f73d42d475977ffcd28ed4771ebbf", null ],
    [ "UndoableCommandMgr", "class_ufe_1_1_undoable_command_mgr.html#afd483afab8907562ba3e4202eece1457", null ],
    [ "executeCmd", "class_ufe_1_1_undoable_command_mgr.html#ac779b6a3bd3073a9b16b3d13aa80c638", null ],
    [ "initializeInstance", "class_ufe_1_1_undoable_command_mgr.html#ad2047081915ecda71463528291efec38", null ],
    [ "instance", "class_ufe_1_1_undoable_command_mgr.html#a6165cef17c916596cd14277032551422", null ],
    [ "operator=", "class_ufe_1_1_undoable_command_mgr.html#a9f01c669233394fefbb0eb877715d953", null ],
    [ "registerCmd", "class_ufe_1_1_undoable_command_mgr.html#a7f38ba9c4630a6c94759922391b08cd4", null ],
    [ "UndoableCommandGuard", "class_ufe_1_1_undoable_command_mgr.html#a7bfd5f143ca61053e6ddd4ab67273cbd", null ]
];