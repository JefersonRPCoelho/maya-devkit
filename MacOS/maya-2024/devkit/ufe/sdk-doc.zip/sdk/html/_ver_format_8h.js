var _ver_format_8h =
[
    [ "Peptide::VersionFormat< VersionTrait >", "class_peptide_1_1_version_format.html", "class_peptide_1_1_version_format" ],
    [ "PEPTIDE_USE_FOUR_FIELD_VERSION", "_ver_format_8h.html#af3bd31fc43cbdc4f4c63f7e5a2517fd0", null ]
];