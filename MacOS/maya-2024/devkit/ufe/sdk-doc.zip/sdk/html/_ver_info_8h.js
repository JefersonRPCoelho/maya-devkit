var _ver_info_8h =
[
    [ "Peptide::VersionInfo", "class_peptide_1_1_version_info.html", "class_peptide_1_1_version_info" ],
    [ "PEPTIDE_USE_FOUR_FIELD_VERSION", "_ver_info_8h.html#af3bd31fc43cbdc4f4c63f7e5a2517fd0", null ]
];