var scene_item_ops_8h =
[
    [ "Ufe::Duplicate", "struct_ufe_1_1_duplicate.html", "struct_ufe_1_1_duplicate" ],
    [ "Ufe::Rename", "struct_ufe_1_1_rename.html", "struct_ufe_1_1_rename" ],
    [ "Ufe::SceneItemOps", "class_ufe_1_1_scene_item_ops.html", "class_ufe_1_1_scene_item_ops" ]
];