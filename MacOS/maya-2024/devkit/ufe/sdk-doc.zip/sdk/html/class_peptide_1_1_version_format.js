var class_peptide_1_1_version_format =
[
    [ "VersionFormat", "class_peptide_1_1_version_format.html#a2579e8f79b172d7873c46400dad08752", null ],
    [ "getVersionID", "class_peptide_1_1_version_format.html#af81266d2a5faf0fad10005a1f7daba2a", null ],
    [ "getVersionInfo", "class_peptide_1_1_version_format.html#a703cc55d297c96e8adcd529832771d60", null ]
];