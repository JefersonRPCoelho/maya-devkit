var struct_ufe_1_1_selection_composite_notification_1_1_op =
[
    [ "Op", "struct_ufe_1_1_selection_composite_notification_1_1_op.html#a7d2c4fca3157ad21336b692b9c9730d9", null ],
    [ "Op", "struct_ufe_1_1_selection_composite_notification_1_1_op.html#ad2e99965dfa7487b2da9029222ddc55c", null ],
    [ "Op", "struct_ufe_1_1_selection_composite_notification_1_1_op.html#aebfb673d4fb1196c1077ca3672e9946a", null ],
    [ "Op", "struct_ufe_1_1_selection_composite_notification_1_1_op.html#af125a58b6f0d25265950516ac7b6c966", null ],
    [ "item", "struct_ufe_1_1_selection_composite_notification_1_1_op.html#a2321b2b3ad6e94d18ad2fc2e40223b49", null ],
    [ "opType", "struct_ufe_1_1_selection_composite_notification_1_1_op.html#af1a4a4f0e3597e243216034a6b2b4939", null ],
    [ "position", "struct_ufe_1_1_selection_composite_notification_1_1_op.html#ab511073a945766f3947a8bed6ed209be", null ]
];