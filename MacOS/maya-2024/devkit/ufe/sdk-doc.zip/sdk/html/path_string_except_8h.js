var path_string_except_8h =
[
    [ "Ufe::EmptyPathSegment", "class_ufe_1_1_empty_path_segment.html", "class_ufe_1_1_empty_path_segment" ],
    [ "Ufe::InvalidPathComponentSeparator", "class_ufe_1_1_invalid_path_component_separator.html", "class_ufe_1_1_invalid_path_component_separator" ],
    [ "Ufe::InvalidPath", "class_ufe_1_1_invalid_path.html", "class_ufe_1_1_invalid_path" ]
];