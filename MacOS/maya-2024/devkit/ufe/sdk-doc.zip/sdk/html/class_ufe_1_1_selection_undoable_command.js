var class_ufe_1_1_selection_undoable_command =
[
    [ "Ptr", "class_ufe_1_1_selection_undoable_command.html#a575c1b1ecf379b7fc5d50f039559ddb4", null ],
    [ "SelectionUndoableCommand", "class_ufe_1_1_selection_undoable_command.html#a4c440ab4b6821ed6fd043b11efb83fa1", null ],
    [ "~SelectionUndoableCommand", "class_ufe_1_1_selection_undoable_command.html#aebb369ebc70bd1438a4db9eda8da0d10", null ],
    [ "targetItem", "class_ufe_1_1_selection_undoable_command.html#ad95e20e09e130fe83deb3ed86c7cd3ed", null ]
];