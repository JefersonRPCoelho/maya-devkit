var struct_ufe_1_1_context_item =
[
    [ "Checkable", "struct_ufe_1_1_context_item.html#a829f01e3b5ccbbdfa2f1a887fac31807", [
      [ "kNotCheckable", "struct_ufe_1_1_context_item.html#a829f01e3b5ccbbdfa2f1a887fac31807a9d0d1c3890d229c01246fad362781037", null ],
      [ "kCheckable", "struct_ufe_1_1_context_item.html#a829f01e3b5ccbbdfa2f1a887fac31807a98115771eb5002400849724e9b856661", null ]
    ] ],
    [ "Checked", "struct_ufe_1_1_context_item.html#a524c6240a2ba7737167a3187bbc603d2", [
      [ "kNotChecked", "struct_ufe_1_1_context_item.html#a524c6240a2ba7737167a3187bbc603d2ae7dbc80fc51cda9f6d05e90375d3af2f", null ],
      [ "kChecked", "struct_ufe_1_1_context_item.html#a524c6240a2ba7737167a3187bbc603d2afcacffbf4c78895cd8814e88488fec63", null ]
    ] ],
    [ "Enabled", "struct_ufe_1_1_context_item.html#acb09dba5e247f419321c6c398127e30a", [
      [ "kDisabled", "struct_ufe_1_1_context_item.html#acb09dba5e247f419321c6c398127e30aacd296c95314ee6bccee393b873c37f2c", null ],
      [ "kEnabled", "struct_ufe_1_1_context_item.html#acb09dba5e247f419321c6c398127e30aa846ab58fd205955f5698475bd0028278", null ]
    ] ],
    [ "Exclusive", "struct_ufe_1_1_context_item.html#a6a134fe528295d1a4939abc4dddeaa9d", [
      [ "kNotExclusive", "struct_ufe_1_1_context_item.html#a6a134fe528295d1a4939abc4dddeaa9da7bb617b99cba2c9d5cc3e78d3fe5ede8", null ],
      [ "kExclusive", "struct_ufe_1_1_context_item.html#a6a134fe528295d1a4939abc4dddeaa9da550a44e217c5e4314a902304e9683e24", null ]
    ] ],
    [ "HasChildren", "struct_ufe_1_1_context_item.html#a292e0ae9d6c1d779bfe2fe76bbd1b678", [
      [ "kNoChildren", "struct_ufe_1_1_context_item.html#a292e0ae9d6c1d779bfe2fe76bbd1b678a4ef6de0f0c5f4afc05b337112215e784", null ],
      [ "kHasChildren", "struct_ufe_1_1_context_item.html#a292e0ae9d6c1d779bfe2fe76bbd1b678aa9dd95a41bafa5ca0695fcf65fc4099f", null ]
    ] ],
    [ "SeparatorTag", "struct_ufe_1_1_context_item.html#a0db5108a0b97b3ba5b4b25d187d9080f", [
      [ "kSeparator", "struct_ufe_1_1_context_item.html#a0db5108a0b97b3ba5b4b25d187d9080fa873b15563d4e7904430c9ac5c6521edd", null ]
    ] ],
    [ "ContextItem", "struct_ufe_1_1_context_item.html#a7743fc2e5ff85d2a943f0abf8ca3a25e", null ],
    [ "ContextItem", "struct_ufe_1_1_context_item.html#a4de174662fdf47a32b0fc49048943fa4", null ],
    [ "ContextItem", "struct_ufe_1_1_context_item.html#a413e2c9d8c1a147a8a82ad23d6355e9e", null ],
    [ "ContextItem", "struct_ufe_1_1_context_item.html#a92f296e01244861bef7b44e06b5c3ab0", null ],
    [ "checkable", "struct_ufe_1_1_context_item.html#ab3b30f239d543d55294ea4e56274006f", null ],
    [ "checked", "struct_ufe_1_1_context_item.html#aad8d697fa78382a5f579e6f8d5204d90", null ],
    [ "enabled", "struct_ufe_1_1_context_item.html#a2320c9f9649698072cd19d50b343db37", null ],
    [ "exclusive", "struct_ufe_1_1_context_item.html#a38c728b24076b0ca382761577647d8a6", null ],
    [ "hasChildren", "struct_ufe_1_1_context_item.html#ad98bb4cda1b09d92dfed6a29beeb8d1c", null ],
    [ "image", "struct_ufe_1_1_context_item.html#a639421078559f48a65bf0eda373213aa", null ],
    [ "item", "struct_ufe_1_1_context_item.html#a53cd17ac76b78fc1963e54892e023e53", null ],
    [ "label", "struct_ufe_1_1_context_item.html#a2aeef070b186b9d7a5ee8e5ca10c4c99", null ],
    [ "separator", "struct_ufe_1_1_context_item.html#a33e4c1e0c66adec66669b46abf865846", null ]
];