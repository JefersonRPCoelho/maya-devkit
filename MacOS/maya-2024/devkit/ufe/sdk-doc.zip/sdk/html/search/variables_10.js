var searchData=
[
  ['textbgcolor_0',['textBgColor',['../struct_ufe_1_1_cell_info.html#a424f1776aab8fe54c684d401d89da8c7',1,'Ufe::CellInfo']]],
  ['textfgcolor_1',['textFgColor',['../struct_ufe_1_1_cell_info.html#a3aaf376c5e10e7d9bf2fdaa523d6f346',1,'Ufe::CellInfo']]],
  ['transform3dhandler_2',['transform3dHandler',['../struct_ufe_1_1_run_time_mgr_1_1_handlers.html#affaeced16daa0e457dfd01214caacabe',1,'Ufe::RunTimeMgr::Handlers']]]
];
