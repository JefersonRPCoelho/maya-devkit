var searchData=
[
  ['separatortag_0',['SeparatorTag',['../struct_ufe_1_1_context_item.html#a0db5108a0b97b3ba5b4b25d187d9080f',1,'Ufe::ContextItem']]],
  ['suboptype_1',['SubOpType',['../class_ufe_1_1_object_delete.html#a93c36bf79d6f2be359e546a0498b65f6',1,'Ufe::ObjectDelete::SubOpType()'],['../class_ufe_1_1_object_path_change.html#af9194dc4ec58a67f4715aaf6228a7d3f',1,'Ufe::ObjectPathChange::SubOpType()']]]
];
