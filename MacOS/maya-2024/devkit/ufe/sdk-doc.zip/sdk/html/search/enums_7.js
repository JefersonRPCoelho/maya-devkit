var searchData=
[
  ['optype_0',['OpType',['../class_ufe_1_1_scene_changed.html#ae03ec89c603bab706842a3f72d936bef',1,'Ufe::SceneChanged::OpType()'],['../class_ufe_1_1_selection_changed.html#a41d311fb10f144f3f7ae6dbb02009070',1,'Ufe::SelectionChanged::OpType()']]]
];
