var searchData=
[
  ['perspective_0',['Perspective',['../class_ufe_1_1_camera.html#a05a61b94a51c2f2a997bc8f5000ad123a9730ff98fca30514df527bc15195649b',1,'Ufe::Camera']]],
  ['point_1',['Point',['../class_ufe_1_1_light.html#a51abe68a80faf447f08f1cb2dc3a9d0aae98271ab03002e91f6dbafabf072485c',1,'Ufe::Light']]]
];
