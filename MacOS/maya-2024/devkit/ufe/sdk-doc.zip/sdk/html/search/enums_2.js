var searchData=
[
  ['enabled_0',['Enabled',['../struct_ufe_1_1_context_item.html#acb09dba5e247f419321c6c398127e30a',1,'Ufe::ContextItem']]],
  ['exclusive_1',['Exclusive',['../struct_ufe_1_1_context_item.html#a6a134fe528295d1a4939abc4dddeaa9d',1,'Ufe::ContextItem']]]
];
