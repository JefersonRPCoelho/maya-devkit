var dir_fdf71392ceb7a6a901c313d9400c2f65 =
[
    [ "peptide", "dir_4ccd1ff52de39ea974c6013cf175a3a5.html", "dir_4ccd1ff52de39ea974c6013cf175a3a5" ],
    [ "ufe", "dir_e974b797394eae9f07f33293b25ed0ab.html", "dir_e974b797394eae9f07f33293b25ed0ab" ]
];