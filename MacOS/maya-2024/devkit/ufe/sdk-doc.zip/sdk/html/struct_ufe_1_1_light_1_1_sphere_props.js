var struct_ufe_1_1_light_1_1_sphere_props =
[
    [ "asPoint", "struct_ufe_1_1_light_1_1_sphere_props.html#af3bd79a992e2038427a415f430330ad3", null ],
    [ "radius", "struct_ufe_1_1_light_1_1_sphere_props.html#ad6ef6d834b01153996b26cce299d3b1f", null ]
];