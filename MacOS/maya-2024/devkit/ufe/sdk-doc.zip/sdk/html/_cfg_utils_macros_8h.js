var _cfg_utils_macros_8h =
[
    [ "PEPTIDE_DEPRECATED", "_cfg_utils_macros_8h.html#a5b351c196fe85d6c27b26b58face07eb", null ],
    [ "PEPTIDE_END_MACRO", "_cfg_utils_macros_8h.html#a472eb4fd7d154feb5ab72b0d9a702cfb", null ],
    [ "PEPTIDE_IDENTITY", "_cfg_utils_macros_8h.html#a83a0c90562ee5e90d42a899d85f0c251", null ],
    [ "PEPTIDE_UNREACHABLE", "_cfg_utils_macros_8h.html#a4d3d22cdad14a621529f442cedc8c7df", null ]
];