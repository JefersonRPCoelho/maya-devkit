var struct_ufe_1_1_b_box3d =
[
    [ "BBox3d", "struct_ufe_1_1_b_box3d.html#a852f643d86388f022223ed20bf5590b4", null ],
    [ "BBox3d", "struct_ufe_1_1_b_box3d.html#a3cab1cd36b9faf43d037505a09b78f25", null ],
    [ "empty", "struct_ufe_1_1_b_box3d.html#a7360e1b41eb2d14ca4e072b2abc0bc21", null ],
    [ "max", "struct_ufe_1_1_b_box3d.html#afd68faccca34295741ab9053ee271d35", null ],
    [ "min", "struct_ufe_1_1_b_box3d.html#a9a32829f7877a8391ce759bbfe618a2d", null ]
];