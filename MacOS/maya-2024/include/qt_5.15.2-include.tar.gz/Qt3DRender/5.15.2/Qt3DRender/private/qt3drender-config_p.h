#define QT_FEATURE_qt3d_opengl_renderer 1
#define QT_FEATURE_qt3d_rhi_renderer -1
